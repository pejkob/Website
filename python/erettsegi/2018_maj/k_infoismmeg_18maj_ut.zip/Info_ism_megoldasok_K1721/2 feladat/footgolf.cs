using System;
using System.Collections.Generic;
using System.IO;

namespace footgolf
{
    struct Versenyző
    {
        public string Név { get; set; }
        public string Kategória { get; set; }
        public string Egyesület { get; set; }
        public byte[] Pontok { get; set; }

        public Versenyző(string sor)
        {
            string[] m = sor.Split(';');
            Név = m[0];
            Kategória = m[1];
            Egyesület = m[2];
            Pontok = new byte[8];
            for (int i = 0; i < Pontok.Length; i++)
            {
                Pontok[i] = byte.Parse(m[i + 3]);
            }
        }

        public int Összpontszám // 5. feladat
        {
            get
            {
                int összpont = 0;
                Array.Sort(Pontok);
                for (int i = 2; i < Pontok.Length; i++)
                {
                    összpont += Pontok[i];
                }
                if (Pontok[0] != 0) összpont += 10;
                if (Pontok[1] != 0) összpont += 10;
                return összpont;
            }
        }
    }

    class footgolf
    {
        static void Main()
        {
            //2. feladat: adatok beolvasása, tárolása
            List<Versenyző> v = new List<Versenyző>();
            foreach (var i in File.ReadAllLines("fob2016.txt"))
            {
                v.Add(new Versenyző(i));
            }

            Console.WriteLine($"3. feladat: Versenyzők száma: {v.Count}");

            int nőiVersenyszőkSzáma = 0;
            foreach (var i in v)
            {
                if (i.Kategória == "Noi") nőiVersenyszőkSzáma++;
            }
            Console.WriteLine($"4. feladat: A női versenyzők aránya: {(double)nőiVersenyszőkSzáma/v.Count:P2}");


            Console.WriteLine("6. feladat: A bajnok női versenyző");
            int maxPont = 0;
            Versenyző bajnokNő = new Versenyző(); 
            foreach (var i in v)
            {
                if (i.Kategória=="Noi" && i.Összpontszám>maxPont)
                {
                    bajnokNő = i;
                    maxPont = i.Összpontszám;
                }
            }

            if (bajnokNő.Összpontszám!=0)
            {
                Console.WriteLine($"\tNév: {bajnokNő.Név}");
                Console.WriteLine($"\tEgyesület: {bajnokNő.Egyesület}");
                Console.WriteLine($"\tÖsszpont: {bajnokNő.Összpontszám}");
            }

            //7. feladat:
            List<string> ki = new List<string>();
            foreach (var i in v)
            {
                if (i.Kategória == "Felnott ferfi")
                {
                    ki.Add($"{i.Név};{i.Összpontszám}");
                }
            }
            File.WriteAllLines("osszpontFF.txt", ki);

            Console.WriteLine("8. feladat: Egyesület statisztika");
            Dictionary<string, int> d = new Dictionary<string, int>();
            foreach (var i in v)
            {
                if (d.ContainsKey(i.Egyesület))
                {
                    d[i.Egyesület]++;
                }
                else
                {
                    d.Add(i.Egyesület, 1);
                }
            }
            foreach (var i in d)
            {
                if (i.Key != "n.a." && i.Value >= 3)
                {
                    Console.WriteLine($"\t{i.Key} - {i.Value} fő");
                }
            }

            Console.ReadKey();
        }
    }
}
